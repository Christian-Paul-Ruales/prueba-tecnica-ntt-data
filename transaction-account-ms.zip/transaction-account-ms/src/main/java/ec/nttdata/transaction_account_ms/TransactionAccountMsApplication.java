package ec.nttdata.transaction_account_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionAccountMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionAccountMsApplication.class, args);
	}

}
