package ec.nttdata.transaction_account_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionAccountMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
